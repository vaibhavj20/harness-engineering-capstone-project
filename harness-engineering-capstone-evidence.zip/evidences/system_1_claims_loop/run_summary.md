# Run summary — 20260924_093842

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1237** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | incomplete | - | - | 2 | 0 | 6267 | 411 | 0.0083 | 4.1 |
| claim_02_stolen_bike | incomplete | - | - | 2 | 0 | 6158 | 420 | 0.0083 | 4.3 |
| claim_03_water_damage | routed | property_damage | high | 5 | 1 | 17467 | 1101 | 0.023 | 12.2 |
| claim_04_neighbor_injury | routed | liability | high | 5 | 0 | 17364 | 859 | 0.0217 | 11.8 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14907 | 927 | 0.0195 | 9.0 |
| claim_06_low_confidence_escalation | incomplete | - | - | 3 | 0 | 9431 | 546 | 0.0122 | 7.5 |
| claim_07_tree_falls_on_car | incomplete | - | - | 2 | 0 | 6398 | 570 | 0.0092 | 6.6 |
| claim_08_minor_porch_damage | routed | property_damage | low | 5 | 0 | 17270 | 856 | 0.0215 | 11.0 |
